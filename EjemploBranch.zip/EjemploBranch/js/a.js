function mostrar(){
    let nombre = document.getElementById("nombre").value;
    alert("Has introducido " + nombre);
}