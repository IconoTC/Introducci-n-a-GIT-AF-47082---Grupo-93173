function saludar(){
    alert("Has pulsado el boton");
}