function mostrar(){
    let nombre = document.getElementById("nombre").value;
    alert("El nombre que has escrito es " + nombre);
}