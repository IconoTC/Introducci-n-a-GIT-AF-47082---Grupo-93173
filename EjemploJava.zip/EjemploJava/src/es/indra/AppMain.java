package es.indra;

import es.indra.models.Alumno;

public class AppMain {

	public static void main(String[] args) {
		
		System.out.println("Hola, que tal?");
		
		Alumno alumno = new Alumno(1, "Juan", 8.34);
		System.out.println(alumno);
		
		System.out.println("Prueba");

	}

}
