package es.indra.models;

public class Alumno {
	
	private int ID;
	private String nombre;
	private double nota;
	
	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(int iD, String nombre, double nota) {
		super();
		ID = iD;
		this.nombre = nombre;
		this.nota = nota;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [ID=" + ID + ", nombre=" + nombre + ", nota=" + nota + "]";
	}
	
	

}
